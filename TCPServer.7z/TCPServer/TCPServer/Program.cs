﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace TCPServer
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpListener server = new(IPAddress.Parse("127.0.0.1"), 13000);
            server.Start();
            while (true)
            {
                TcpClient client = null;
                try
                {
                    Console.Write("Waiting for a connection... ");
                    // Perform a blocking call to accept requests.
                    // You could also use server.AcceptSocket() here.
                    client = server.AcceptTcpClient();
                    Console.WriteLine("Connected!");

                    int i;
                    byte[] bytes = new byte[2048];
                    StringBuilder sb = new();
                    string request, response;
                    NetworkStream stream = client.GetStream();
                    // Loop to receive all the data sent by the client.
                    while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                    {
                        // Translate data bytes to a ASCII string.
                        sb.Append(Encoding.ASCII.GetString(bytes, 0, i));
                        if (!stream.DataAvailable) break;
                    }
                    request = sb.ToString();
                    Console.Write(request);
                    if (request.Contains("__SERVER_STOP"))
                    {
                        client.Close();
                        Console.WriteLine("Exiting...");
                        break;
                    }
                    if (request.StartsWith("GET /") && request.Contains(" HTTP"))
                    {
                        response = "HTTP/1.1 403 Forbidden\r\nDate: " + DateTime.Now.ToUniversalTime().ToString("R") + "\r\n\r\n";
                        Console.Write(response);
                        byte[] msg = Encoding.ASCII.GetBytes(response);
                        stream.Write(msg, 0, msg.Length);
                        string base64Url = request.Substring(5, request.IndexOf(" HTTP") - 5);
                        Console.WriteLine(base64Url);
                        Process.Start("partialdownloadgui.exe", base64Url);
                    }
                    client.Close();
                    Console.WriteLine("Connection closed.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    client.Close();
                    continue;
                }
            }
            server.Stop();
        }
    }
}
